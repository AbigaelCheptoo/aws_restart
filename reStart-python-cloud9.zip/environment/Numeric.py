print("Python has three numeric types: int, float, and complex")
myValue=3.14
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))